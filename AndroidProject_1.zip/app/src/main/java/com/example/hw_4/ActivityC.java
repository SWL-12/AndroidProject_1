package com.example.hw_4;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

public class ActivityC extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_c);

        Button btOpenActA = findViewById(R.id.btOpenActA);

        btOpenActA.setOnClickListener(view -> {
            Intent intent = new Intent(this, ActivityA.class);
            startActivity(intent);
        });

        Button btOpenActD = findViewById(R.id.btOpenActD);

        btOpenActD.setOnClickListener(view -> {
            Intent intent = new Intent(this, ActivityD.class);
            finishAffinity();
            startActivity(intent);
        });

        Button btCloseActC = findViewById(R.id.btCloseActC);

        btCloseActC.setOnClickListener(view -> {
            Intent intent = new Intent(this, ActivityB.class);
            startActivity(intent);
        });

        Button btCloseStack = findViewById(R.id.btCloseStack);

        btCloseStack.setOnClickListener(view -> {
            finishAffinity();
        });
    }
}